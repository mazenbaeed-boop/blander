// script.js - interactions for Bulender
document.addEventListener('DOMContentLoaded', function(){

  // language switch
  const arabicBtn = document.getElementById('arabicBtn');
  const englishBtn = document.getElementById('englishBtn');
  function setLang(lang){
    const html = document.documentElement;
    if(lang==='ar'){ html.lang='ar'; html.dir='rtl'; }
    else { html.lang='en'; html.dir='ltr'; }
    // simple text swap for main elements
    const title = document.querySelector('.hero-content h1');
    const para = document.querySelector('.hero-content p');
    const btnMain = document.querySelector('.main-btn');
    if(lang==='ar'){
      title.textContent='نبني المستقبل مع بلندر';
      para.textContent='حلول متكاملة للمقاولات والتشييد، تنفيذ محترف، وتسليم في المواعيد.';
      btnMain.textContent='اطلب عرض';
    } else {
      title.textContent='We Build The Future With Bulender';
      para.textContent='Integrated construction solutions, professional delivery and on-time completion.';
      btnMain.textContent='Request Quote';
    }
  }
  arabicBtn.addEventListener('click', ()=> setLang('ar'));
  englishBtn.addEventListener('click', ()=> setLang('en'));

  // reveal on scroll
  const animEls = document.querySelectorAll('[data-anim]');
  const obs = new IntersectionObserver((entries)=>{
    entries.forEach(e=>{ if(e.isIntersecting) e.target.classList.add('show'); });
  },{threshold:0.15});
  animEls.forEach(el=>obs.observe(el));

  // counters
  document.querySelectorAll('[data-count]').forEach(el=>{
    const to = +el.getAttribute('data-count');
    let start = 0;
    const step = Math.ceil(to/60);
    const id = setInterval(()=>{
      start += step;
      if(start>=to){ el.textContent = to; clearInterval(id); } else el.textContent = start;
    },30);
  });

  // smooth scroll for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(a=>{
    a.addEventListener('click', function(e){
      e.preventDefault();
      document.querySelector(this.getAttribute('href')).scrollIntoView({behavior:'smooth'});
    });
  });

  // quick modal
  const quickModal = document.getElementById('quickModal');
  const openQuick = document.getElementById('openQuick');
  const modalClose = document.getElementById('modalClose');
  openQuick.addEventListener('click', ()=> quickModal.setAttribute('aria-hidden','false'));
  modalClose.addEventListener('click', ()=> quickModal.setAttribute('aria-hidden','true'));
  quickModal.addEventListener('click', (e)=>{ if(e.target===quickModal) quickModal.setAttribute('aria-hidden','true'); });

  // quick form submit (fake submit - shows message)
  document.getElementById('quickForm').addEventListener('submit', function(e){
    e.preventDefault();
    const qMsg = document.getElementById('qMsg');
    qMsg.textContent = 'تم إرسال طلبك! سنعاود الاتصال خلال 24 ساعة.';
    this.reset();
  });

  // contact form ajax (progressive: will submit to contact.php)
  const contactForm = document.getElementById('contactForm');
  contactForm.addEventListener('submit', function(e){
    // let the form submit normally to contact.php; optionally you can implement fetch here.
    const formMsg = document.getElementById('formMsg');
    formMsg.textContent = 'جاري الإرسال...';
  });

});
